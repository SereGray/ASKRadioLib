#include <criterion/criterion.h>

Test(first_suite, test) {
    cr_assert(1);
}

Test(second_suite, test) {
    cr_assert(1);
}
