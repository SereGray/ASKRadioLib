#include <criterion/criterion.h>

Test(samples, timed) {
    cr_assert(0);
}
