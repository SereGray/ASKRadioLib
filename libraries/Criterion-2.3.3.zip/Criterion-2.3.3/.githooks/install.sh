#!/bin/sh

rm -Rf .git/hooks
ln -s ../.githooks .git/hooks
