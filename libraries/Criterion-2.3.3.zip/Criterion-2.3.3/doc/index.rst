Criterion
=========

 .. toctree::
    :maxdepth: 2 

    intro
    setup
    starter
    assert
    hooks
    logging
    env
    output
    parameterized
    theories
    internal
    debug
    faq
